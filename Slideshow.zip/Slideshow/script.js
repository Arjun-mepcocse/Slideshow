const slides = document.querySelectorAll(".slide");
const dots = document.querySelectorAll(".dot");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");

let current = 0;

function showSlide(index) {
    //Wrap around at the ends
    if ( index >= slides.length) {
        index = 0;
    }

    if (index < 0) {
        index = slides.length - 1;
    }

    //Hide everything
    slides.forEach(function (s) { s.classList.remove("active");});
    dots.forEach(function (d) { d.classList.remove("active");});

    // Show the chosen slide and its dot

    slides[index].classList.add("active");
    dots[index].classList.add("active");

    current = index;
}

nextBtn.addEventListener("click", function () {
    showSlide(current + 1);
});

prevBtn.addEventListener("click", function() {
    showSlide(current - 1);
});

// Clicking a dot jumps to that slide
dots.forEach(function (dot, i) {
    dot.addEventListener("click", function () {
        showSlide(i);
    });
});
